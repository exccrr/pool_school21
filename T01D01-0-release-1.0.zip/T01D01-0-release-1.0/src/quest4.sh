ps axu | grep ai_door_control
kill 79044
