1) cd ai_help
2) sh keygen.sh
3) cd key
4) ls -la
5) rm -f file*
6) cd ..
7) sh unifier.sh
8) cd key
9) mv main.key key
