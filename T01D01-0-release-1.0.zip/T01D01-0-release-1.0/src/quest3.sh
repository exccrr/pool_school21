mv door_management_fi door_management_files
mkdir door_logs door_map door_configuration
cp *.conf door_configuration
cp *.log  door_logs
mv door_map_1.1 door_map
chmod -R 777 door_management_files
